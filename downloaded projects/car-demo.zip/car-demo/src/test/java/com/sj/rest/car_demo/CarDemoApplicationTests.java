package com.sj.rest.car_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
