package com.sj.carapp.carapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarapplicationApplication.class, args);
	}

}
