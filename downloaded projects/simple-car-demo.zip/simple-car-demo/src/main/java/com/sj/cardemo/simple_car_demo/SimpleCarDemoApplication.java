package com.sj.cardemo.simple_car_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleCarDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleCarDemoApplication.class, args);
	}

}
