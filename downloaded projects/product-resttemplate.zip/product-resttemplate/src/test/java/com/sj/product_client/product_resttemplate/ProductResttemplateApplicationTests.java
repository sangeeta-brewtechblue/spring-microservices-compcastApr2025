package com.sj.product_client.product_resttemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductResttemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
