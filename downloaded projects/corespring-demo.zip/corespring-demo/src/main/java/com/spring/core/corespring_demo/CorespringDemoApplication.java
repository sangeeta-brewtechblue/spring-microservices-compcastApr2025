package com.spring.core.corespring_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorespringDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorespringDemoApplication.class, args);
	}

}
