package com.spring.core.corespring_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorespringDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
